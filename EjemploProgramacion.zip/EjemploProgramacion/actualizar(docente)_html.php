<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="estilo.css">
    <link rel="stylesheet" type="text/css" href="menu.css">
    <link rel="stylesheet" type="text/css" href="base.css">
    <title>Document</title>
</head>
<body><nbsp>
  <?php include("menu.php")?>
    <?php 
    include("actualizar(docente)_codigo.php")
    
    ?>
    <section id="container">

    <form method="post">
    	<h1>ingrese los datos del docente</h1>
		<h3>documento: <?php echo $id;?></h3>
    	<input type="text" name="2" value="<?php echo $nombre;?>" placeholder="Nombre completo">
		<input type="text" name="3"value="<?php echo $apellido;?>" placeholder="ingrese su apellido">
		<input type="number" name="4"value="<?php echo $tel;?>" placeholder="ingrese su numero de telefono">
		<input type="text" name="5"value="<?php echo $dir;?>"placeholder="ingrese su direcion">
    	<input type="text" name="6"value="<?php echo $email;?>" placeholder="Email">
		<input type="text" name="7" value="<?php echo $con;?>"placeholder="contraseña">
    	<input type="submit"  value="actualizar"name="actualizar">
		<a href="consultar_docente.php">Cosultar docente</a>
		
    </form>

    
    </section>
</nbsp>
</body>
</html>
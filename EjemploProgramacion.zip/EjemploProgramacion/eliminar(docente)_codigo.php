<?php 
if(empty($_REQUEST["id"])){ alert("es posible que ese id no exista") ;header("location:consultar_docente.php");}else{
    include("con_db.php");
    $id=$_REQUEST["id"];
    $consulta=mysqli_query($conexion,"SELECT *FROM docente WHERE id_doncente = '$id'");
    $resultado=mysqli_num_rows($consulta);
        if($resultado>0){
            while($pro=mysqli_fetch_array($consulta)){
                $id = $pro['id_doncente'];
	    $nombre = $pro['nombre_docente'];
        $apellido=$pro['apellido_docente'];
        $tel=$pro['telefono'];
        $dir=$pro['direccion'];
	    $email = $pro['usuario'];
	    $con = $pro['contraseña'];
            }
            
            if(isset($_POST['eliminador'])){
                $codigo="DELETE FROM docente where id_doncente='$id'";
        $resultado=mysqli_query($conexion,$codigo);
        if($resultado){  echo'<script>
            
            alert("se a eliminado correctamente");
            location="consultar_docente.php";
            
            </script>';  }
            }
            
            ?>



<?php
}else{?>

<?php
}

}
?>

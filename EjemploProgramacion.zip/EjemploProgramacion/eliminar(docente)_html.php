<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="estilo.css">
    <link rel="stylesheet" type="text/css" href="menu.css">
    <link rel="stylesheet" type="text/css" href="base.css">
    <title>Eliminar registro</title>
</head>
    <body>
 
<?php  include("eliminar(docente)_codigo.php"); ?>
<?php  include("menu.php"); ?>
<section id="container"> 
<div> <form method="post">
    <h2>¿estas seguro de elinar al siguente docente de la base de datos?</h2>
    <p>documento:<span><?php echo $id;  ?></span></p>
    <p>nombre:<span><?php echo $nombre;  ?></span></p>
    <p>apellido:<span><?php echo $apellido;  ?></span></p>
    <p>numero de telefono :<span><?php echo $tel;  ?></span></p>
    <p>direcion:<span><?php echo $dir;  ?></span></p>
    <p>usuario:<span><?php echo $email;  ?></span></p>
    <p>contraseña:<span><?php echo $con;  ?></span></p>
    

        <a href="consultador.php">cancelar</a>
        <input type="submit" value="eliminar" name="eliminador">
    </form>
</div>
</section> 
    </body>
</html>
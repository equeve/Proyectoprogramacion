

    <table>
<tr><center>
        <th>matricula</th>
        <th>nombre</th>
        <th>apellido</th>
        <th>curso</th>
        <th>lugar de nacimiento</th>
        <th>fecha de nacimiento</th>
        <th>vive con</th>
        <th>edad</th>
        <th>eps</th>
        <th>sisben</th>
        <th>fecha del reporte</th>
        <th>motivo del reporte</th>
        <th>docente relizo el reporte</th>
        <th>opciones</th>
    
    </tr><?php 

$xd = include("con_db.php");

if ($xd) {
    if(isset($_POST['consultador2'])){
        if ($_POST['m']==0) { $c=$_POST['m'];
            $consulta="SELECT*FROM reporte   INNER JOIN estudiante ON reporte.matricula_estudiante=estudiante.matricula_estudiante where  reporte.matricula_estudiante='$c'";
        }else{$consulta="SELECT*FROM reporte INNER JOIN estudiante ON reporte.matricula_estudiante=estudiante.matricula_estudiante";}
    }else{$consulta="SELECT*FROM reporte INNER JOIN estudiante ON reporte.matricula_estudiante=estudiante.matricula_estudiante";};
	
	$resultado = mysqli_query($conexion,$consulta);
	if ($resultado) {
		while ($pro = $resultado->fetch_array()) {
	    $id = $pro['matricula_estudiante'];
	    $nombre = $pro['nombre'];
        $apellido=$pro['apellido'];
        $curso=$pro['curso'];
        $nac=$pro['lugar_nacimiento'];
        $fec=$pro['fecha_nacimiento'];
	    $vive_con= $pro['vive_con'];
	    $edad = $pro['edad'];
        $EPS=$pro['EPS'];
        $sis=$pro['sisben'];
        $fecha=$pro['fecha'];
        $anotaciones=$pro['anotaciones'];
        $id_d=$pro['id_doncente'];
        $id_reporte=$pro['id_reporte']
	    ?>
                <tr>
        			<td> <?php echo$id; ?></td>
                    <td><?php echo $nombre; ?></td>
                    <td>  <?php echo $apellido; ?></td>
                  <td><?php  echo $curso; ?></td> 
                  <td> <?php echo $nac; ?></td>
        		   <td> <?php echo $fec; ?></td>
                     <td> <?php echo $vive_con; ?></td>
                      <td> <?php echo $edad; ?></td>
                      <td> <?php echo $EPS; ?></td>
                      <td> <?php echo $sis; ?></td> 
                      <td> <?php echo $fecha; ?></td> 
                      <td> <?php echo $anotaciones; ?></td> 
                      <td> <?php echo $id_d; ?></td>
                      <td> <a href="eliminar(reporte)_html.php?id=<?php echo $pro['id_reporte'] ; ?>" style="color:red">eliminar</a></td>
                    </center>
                 </tr>    
        		   
        	
	    <?php
	    }
	}
}
?></table>

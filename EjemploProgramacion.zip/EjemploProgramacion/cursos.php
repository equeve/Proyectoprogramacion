<?php
$xd=include("con_db.pho");
if ($_POST['cursos']!="no"){
  $curso_p=$_POST['cursos'];
  $consulta = "SELECT * FROM docente";
	$resultado = mysqli_query($conexion,$consulta);
  if($resultado){

    
  }








}







?>
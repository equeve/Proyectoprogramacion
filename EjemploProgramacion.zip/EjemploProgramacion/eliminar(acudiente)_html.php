<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="estilo.css">
    <link rel="stylesheet" type="text/css" href="menu.css">
    <link rel="stylesheet" type="text/css" href="base.css">
    <title>Eliminar registro</title>
</head>
    <body>
    <?php  include("menu.php"); ?>
<?php  include("eliminar(acudiente)_codigo.php"); ?>

<section id="container"> <form method="post"><div>
    <h2>¿estas seguro de eliminar al siguente docente de la base de datos?</h2>
    <p>documento:<span><?php echo $id;  ?></span></p>
    <p>nombre:<span><?php echo $nombre;  ?></span></p>
    <p>apellido:<span><?php echo $apellido;  ?></span></p>
    <p>numero de telefono:<span><?php echo $telefono;  ?></span></p>
    <p>direcion:<span><?php echo $dir;  ?></span></p>
    <p>sexo:<span><?php echo $sexo;  ?></span></p>
    <p>matricula del estudainte:<span><?php echo $estudiante;  ?></span></p>
    

        <a href="consultador.php">cancelar</a>
        <input class="eliminar" type="submit"  value="eliminar" name="eliminador">
    </form>
</div>
</section> 
    </body>
</html>
<!DOCTYPE html>
<html>
<head>
	<title>Registrar usuario</title>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="estilo.css">
  <link rel="stylesheet" type="text/css" href="menu.css">
  <link rel="stylesheet" type="text/css" href="base.css">
</head>

<body>

<?php include("menu.php")
?>
    <form method="post">
    	<h1>ingrese los datos del reporte</h1>
        
		

        <input type="number" name="id_estudiante" placeholder="ingrese la matricula del estudiante">
		<input type="text" name="motivo" placeholder="motivo del reporte">
        <a href="consultador_es.php">estudiantes</a>
        <input type="date" name="fecha" placeholder="motivo del reporte">
		<input type="number" name="i_doc" placeholder="ingrese su documento">
    	<input type="submit" name="register_5">
    </form>
        <?php 
        include("registrar5.php");
        ?>
</body>
</html>
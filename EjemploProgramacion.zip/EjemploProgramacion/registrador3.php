<?php
include("con_db.php");
$formulario=[0];

if(isset($_POST['register_3'])){
for ($i=1;$i<5;$i++){
if(strlen($_POST["$i"]) == 0){
?>
<h3 class="bad">por favor complete todos los campos</h3>
<?php
exit();
}
if(strlen($_POST["$i"]) == 1  ){
    $x=$_POST["$i"];
    $verificacion= mysqli_query($conexion,"SELECT*FROM curso where codigo ='$x'");
    if(mysqli_num_rows($verificacion) >0){
        echo'<script>
        alert("codigo de curso ya registrado");
        location="curso.php";
        </script>';
        exit();}}$formulario[$i]=$_POST["$i"];}
        $consulta = "INSERT INTO curso (codigo,id_doncente,modalidad,jornada) VALUES ('$formulario[1]', '$formulario[2]', '$formulario[3]', '$formulario[4]');";
	    $resultado = mysqli_query($conexion,$consulta);
        if($resultado){
            ?><h1 class="ok">registradon con exito</h1><?php
        }else{?><h1 class="bad">error en la registracion</h1><?php
        }
}
?>
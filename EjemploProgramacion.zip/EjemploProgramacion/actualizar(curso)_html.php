<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="estilo.css">
    <link rel="stylesheet" type="text/css" href="menu.css">
    <link rel="stylesheet" type="text/css" href="base.css">
    <title>Document</title>
</head>
<body><nbsp>
  <?php include("menu.php")?>
    <?php 
    include("actualizar(curso)_codigo.php")
    
    ?>
    <section id="container">

    <form method="post">
    	<h1>ingrese los datos del curso</h1>
		<h3>curso: <?php echo $codigo;?></h3>
    	<select type="text" name="2" value="<?php echo $jornada; ?>" required>
                    <option value= "mañana">jornada de la mañana</option>
                    <option value="tarde">jornada de la tarde</option>
                    <option value= "unica">jornada unica</option>
                </select>
                <select type="text" name="3"  value="<?php echo $modalidad;?>" placeholder="elija la modalidad" required>
                <?php  include("con_db.php"); 
            
            $consulta="SELECT * FROM modalidad";
            $ejecutar=mysqli_query($conexion,$consulta) or die(mysqli_error($conexion));
            ?>
            <?php foreach($ejecutar as $opciones):?>
            
        <option value="<?php echo $opciones['nombre']?>"><?php echo $opciones['nombre']?> </option>

            <?php   endforeach  ?>
                </select>   
                <input type="number" name="4" value="<?php echo $id_doncente;?>" placeholder="ingrese el id del dicretor del curspo">
    	<input type="submit" value="actualizar" name="actualizar">
		<a href="consultar_docente.php">Cosultar docente</a>
		
    </form>

    
    </section>
</nbsp>
</body>
</html>
<?php 
if(empty($_REQUEST["id"])){ alert("es posible que ese id no exista") ;header("location:consultador_es.php");}else{
    include("con_db.php");
    $id=$_REQUEST['id'];
    $consulta=mysqli_query($conexion,"SELECT *FROM estudiante WHERE matricula_estudiante='$id'");
    $resultado=mysqli_num_rows($consulta);
        if($resultado>0){
            while($pro=mysqli_fetch_array($consulta)){
        $id = $pro['matricula_estudiante'];
	    $nombre = $pro['nombre'];
        $apellido=$pro['apellido'];
        $curso=$pro['curso'];
        $fecha=$pro['fecha_nacimiento'];
        $nac=$pro['lugar_nacimiento'];
	    $vive_con= $pro['vive_con'];
	    $edad = $pro['edad'];
        $EPS=$pro['EPS'];
        $sis=$pro['sisben'];
            }
        }
    }
if(isset($_POST["actualizar2"])){
    for ($i=2;$i<11;$i++){
        if(strlen($_POST["$i"]) == 0){
            ?>
            <h3 class="bad">por favor complete todos los campos</h3>
            <?php
            exit();
            };
            $formulario[$i]=$_POST["$i"];
    };
    $actualizar="UPDATE estudiante SET nombre='$formulario[2]', apellido='$formulario[3]' ,curso='$formulario[4]' ,lugar_nacimiento='$formulario[5]',fecha_nacimiento='$formulario[6]',vive_con='$formulario[7]',edad='$formulario[8]',EPS='$formulario[9]',sisben='$formulario[10]' where matricula_estudiante='$id'; ";
$resultado=mysqli_query($conexion,$actualizar);
if($resultado){

    echo'<script>
        
        alert("se a actualizado correctamente");
        location="consultador_es.php";
        
        </script>'; 
};
};


    ?>
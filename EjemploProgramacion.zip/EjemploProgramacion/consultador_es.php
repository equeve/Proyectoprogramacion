<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="consulta.css">
    <link rel="stylesheet" type="text/css" href="menu.css">
    <link rel="stylesheet" type="text/css" href="base.css">
</head>
<body>
    
<nbsp>
<?php
include("menu.php")

?>
    <center>
    <form method="post" >
        <select name="e_curso" id="">
    <option  type="text" value=0>todos</option>
    <?php  include("con_db.php"); 
            
            $consul="SELECT * FROM curso";
            $ejecutar=mysqli_query($conexion,$consul) or die(mysqli_error($conexion));
            ?>
            <?php foreach($ejecutar as $opciones):?>
            
        <option value="<?php echo $opciones['codigo']?>"><?php echo $opciones['codigo']?> </option>

            <?php   endforeach  ?>
        </select>
        <input type="submit" name="consultador1">
    </form></center>
    <?php include("consulta(es).php"); ?></nbsp>
</body>
</html>
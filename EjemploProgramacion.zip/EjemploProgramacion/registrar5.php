<?php 

include("con_db.php"); 

if (isset($_POST['register_5'])) {
    if (strlen($_POST['id_estudiante']) >= 1 &&strlen($_POST['motivo']) >= 1 && strlen($_POST['fecha']) >= 1  && strlen($_POST['i_doc']) >= 1 ) {
        $id_estudiante=trim($_POST['id_estudiante']);
	    $motivo=trim($_POST['motivo']);
        $fecha=trim($_POST['fecha']);
        $i_doc=trim($_POST['i_doc']);


		$verificacion= mysqli_query($conexion,"SELECT*FROM docente where id_doncente ='$i_doc';");
        if(mysqli_num_rows($verificacion) ==0){
            echo'<script>
            
            alert("error docente no existe");
            location="reporte.php";
            
            </script>';
            exit();
        };
	    $consulta = "INSERT INTO reporte (matricula_estudiante,fecha,anotaciones,id_doncente,id_reporte) VALUES ('$id_estudiante', '$fecha', '$motivo', '$i_doc', NULL)";
		$verificacion= mysqli_query($conexion,"SELECT*FROM estudiante where matricula_estudiante ='$id_estudiante';");
        if(mysqli_num_rows($verificacion) ==0){
            echo'<script>
            
            alert("error este estudiante no existe");
            location="estudiante.php";
            
            </script>';
            exit();
        }
	    $resultado = mysqli_query($conexion,$consulta);
	    if ($resultado) {
	    	?> 
	    	<h3 class="ok">Te has inscripto correctamente</h3>
           <?php
	    } else {
	    	?> 
	    	<h3 class="bad"> ha ocurrido un error</h3>
           <?php
	    }
    }   else {
	    	?> 
	    	<h3 class="bad">Por favor complete los campos</h3>
           <?php
    }
}

?>
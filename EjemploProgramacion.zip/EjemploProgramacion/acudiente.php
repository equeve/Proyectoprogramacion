<!DOCTYPE html>
<html>
<head>
	<title>acudiente</title>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="estilo.css">
	<link rel="stylesheet" type="text/css" href="base.css">
  <link rel="stylesheet" type="text/css" href="menu.css">
</head>
<body>
<header>
  <?php 
  include("menu.php")
  ?>
  <nbsp> 
    <form method="post">
    	<h1>ingrese los datos del acudiente</h1>
		<input type="number" name="1" placeholder="ingrese su cedula">
    	<input type="text" name="2" placeholder="Nombre completo">
		<input type="text" name="3" placeholder="ingrese su apellido">
		<input type="number" name="4" placeholder="ingrese su numero de telefono">
		<input type="text" name="5" placeholder="ingrese su direccion">
    	<select name="6" id="">
		<option value="femenino">femenino</option>
		<option value="masculino">masculino</option>
		</select>
		<input type="number" name="7" placeholder="ingrese el documento del estudiante">
    	<input type="submit" name="register_4">

    </form>
        <?php 
        include("registrador4.php");
        ?></nbsp>   
</body>
</html>
<?php
include("con_db.php");
$formulario=[0];

if(isset($_POST['register'])){
for ($i=1;$i<8;$i++){
if(strlen($_POST["$i"]) == 0){
?>
<h3 class="bad">por favor complete todos los campos</h3>
<?php
exit();
}
if(strlen($_POST["$i"]) == 6 or strlen($_POST["$i"]) == 1 ){
    $x=$_POST["$i"];
    $verificacion= mysqli_query($conexion,"SELECT*FROM docente where usuario ='$x' or
    id_doncente ='$x'");
    if(mysqli_num_rows($verificacion) >0){
        echo'<script>
        alert("error usuario ya registrado");
        location="indice.php";
        </script>';
        exit();}}$formulario[$i]=$_POST["$i"];}
        $consulta = "INSERT  INTO docente(id_doncente,nombre_docente,apellido_docente,telefono,direccion,usuario, contraseña) VALUES ('$formulario[1]','$formulario[2]','$formulario[3]','$formulario[4]','$formulario[5]','$formulario[6]','$formulario[7]')";
	    $resultado = mysqli_query($conexion,$consulta);
        if($resultado){
            ?><h1 class="ok">registradon con exito</h1><?php
        }else{?><h1 class="bad">error en la registracion</h1><?php
        }
}
?>
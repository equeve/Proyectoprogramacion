<?php 
if(empty($_REQUEST['id'])){ alert("es posible que ese id no exista") ;header("location:consultar_docente.php");}else{
    include("con_db.php");
    $codigo=$_REQUEST["id"];
    $consulta=mysqli_query($conexion,"SELECT *FROM curso WHERE codigo = '$codigo'");
    $resultado=mysqli_num_rows($consulta);
        if($resultado>0){
            while($pro=mysqli_fetch_array($consulta)){
                $codigo = $pro['codigo'];
                $id_doncente=$pro['id_doncente'];
                $modalidad=$pro['modalidad'];
                $jornada=$pro['jornada'];
            }
            
            if(isset($_POST['eliminador'])){
                $codigo="DELETE FROM curso WHERE codigo = '$codigo'";
        $resultado=mysqli_query($conexion,$codigo);
        if($resultado){  echo'<script>
            
            alert("se a eliminado correctamente");
            location="consulta(cu).php";
            
            </script>';  }
            }
            
            ?>



<?php
}else{?>

<?php
}

}
?>

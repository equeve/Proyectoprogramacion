<?php
include('con_db.php');
if(isset($_POST['ingresar']) ){
$usuario=$_POST['usuario'];
$contraseña=$_POST['contraseña'];


$verificacion= mysqli_query($conexion,"SELECT*FROM docente where usuario='$usuario' and contraseña='$contraseña'");
if(mysqli_num_rows($verificacion) >=1){
 echo '<script>
            
            alert("estas dentro");
            location="index.php";
            
            </script>';
}else{
    ?>

  <h1 class="bad">ERROR DE AUTENTIFICACION</h1>
  <?php
}
}
?>
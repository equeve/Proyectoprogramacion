<?php 
if(empty($_REQUEST["id"])){ alert("es posible que ese id no exista") ;header("location:consultar_docente.php");}else{
    include("con_db.php");
    $id=$_REQUEST["id"];
    $consulta=mysqli_query($conexion,"SELECT *FROM docente WHERE id_doncente = '$id'");
    $resultado=mysqli_num_rows($consulta);
        if($resultado>0){
            while($pro=mysqli_fetch_array($consulta)){
                $id = $pro['id_doncente'];
	    $nombre = $pro['nombre_docente'];
        $apellido=$pro['apellido_docente'];
        $tel=$pro['telefono'];
        $dir=$pro['direccion'];
	    $email = $pro['usuario'];
	    $con = $pro['contraseña'];
            };
            $formulario=[0];
            
if(isset($_POST['actualizar'])){

    for ($i=2;$i<8;$i++){
        if(strlen($_POST["$i"]) == 0){
            ?>
            <h3 class="bad">por favor complete todos los campos</h3>
            <?php
            exit();
            };
            $formulario[$i]=$_POST["$i"];
    };
    $actualizar="UPDATE docente SET nombre_docente='$formulario[2]',apellido_docente='$formulario[3]',telefono='$formulario[4]',direccion='$formulario[5]',usuario='$formulario[6]',contraseña='$formulario[7]' where id_doncente='$id'; ";
    $resultado=mysqli_query($conexion,$actualizar);
    if($resultado){

        echo'<script>
            
            alert("se a actualizado correctamente");
            location="consultar_docente.php";
            
            </script>'; 
    }

   }
}
}                   
?>

<table border= 1px; >
    <tr><center>
        <th>documento</th>
        <th>nombre</th>
        <th>apellido</th>
        <th>telefono</th>
        <th>direccion</th>
        <th>usuario</th>
        <th>contraseña</th>
        <th>opciones</th>
    </center>
    </tr>
   
<?php 
$xd = include("con_db.php");
if ($xd) {
    if(isset($_POST['t'])){if($_POST['a']){
        $a=$_POST['a'];$consulta = "SELECT * FROM docente where id_doncente ='$a'";
    }else{$consulta = "SELECT * FROM docente";};
    
    }else{$consulta = "SELECT * FROM docente";}
	
	$resultado = mysqli_query($conexion,$consulta);
	if ($resultado) {
		while ($pro = $resultado->fetch_array()) {
	    $id = $pro['id_doncente'];
	    $nombre = $pro['nombre_docente'];
        $apellido=$pro['apellido_docente'];
        $tel=$pro['telefono'];
        $dir=$pro['direccion'];
	    $email = $pro['usuario'];
	    $con = $pro['contraseña'];
	    ?><center>
                <tr>
        			<td> <?php echo$id; ?></td>
                    <td><?php echo $nombre; ?></td>
                    <td>  <?php echo $apellido; ?></td>
                  <td><?php  echo $tel; ?></td> 
                  <td> <?php echo $dir; ?></td>
        		   <td> <?php echo $email; ?></td>
                     <td> <?php echo $con; ?></td>
                     <td> <nbsp><a href="eliminar(docente)_html.php?id=<?php echo $id; ?>" style=color:red > eliminar<a> <p>-</p> <a href="actualizar(docente)_html.php?id=<?php echo $id; ?>" style=color:#7CFC00> actualizar<a> </nbsp>
                         
                     </td>
                 </tr>    
        		    </center>
        	
	    <?php
	    }
	}
}
?>   

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="estilo.css">
    <link rel="stylesheet" type="text/css" href="menu.css">
    <link rel="stylesheet" type="text/css" href="base.css">
    <title>Document</title>
</head> 
<?php 
    include("actualizar(estudiante)_codigo.php")
    
    ?>
<body><nbsp>
    
<?php
include("menu.php")
?>
<form method="post">
    	<h1>ingrese los datos del estudiante</h1>
		<h1> <?php echo $id ; ?></h1>
    	<input type="text" name="2" value="<?php echo $nombre ; ?>" placeholder="Nombre completo">
		<input type="text" name="3" value="<?php echo $apellido ; ?>"  placeholder="apellido">
		<select type="number" name="4"value="<?php echo $curso ; ?>"  placeholder="codigo de curso">
        <?php  include("con_db.php"); 
            
            $consul="SELECT * FROM curso";
            $ejecutar=mysqli_query($conexion,$consul) or die(mysqli_error($conexion));
            ?>
            <?php foreach($ejecutar as $opciones):?>
            
        <option value="<?php echo $opciones['codigo']?>"><?php echo $opciones['codigo']?> </option>

            <?php   endforeach  ?>
        </select>
		<input type="date" name="5" value="<?php echo $nac ; ?>"  placeholder="lugar de nacimiento">
    	<input type="date" name="6"value="<?php echo $fecha; ?>"  placeholder="fecha de nacimiento">
		<select type="text" name="7"value="<?php echo $vive_con ; ?>"  class="form-control" required>
                    <option value= "padres">padres</option>
                    <option value="mama">mama</option>
                    <option value= "papa">papa</option>
                </select>
        <input type="number" name="8"value="<?php echo $edad ; ?>"  placeholder="edad">
        <input type="text" name="9"value="<?php echo $EPS ; ?>"  placeholder="eps">
        <input type="text" name="10"value="<?php echo $sis; ?>"  placeholder="sisben">
    	<input type="submit" value="actualizar" name="actualizar2">
        <?php 
        include("registrador2.php");
        ?>
    </form>
  
   
    <section id="container">

    

    
    </section>
</nbsp>
</body>
</html>
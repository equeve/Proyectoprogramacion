<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Menú Responsive</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.0/css/all.min.css" rel="stylesheet">


<style>

*{
    padding: 0;
    margin: 0;
    text-decoration: none;
    list-style: none;
    box-sizing: border-box;
}

nav{
    background: dodgerblue;
    height: 100px;
    width: 100%;
}
.enlace{
    position: absolute;
    padding: 20px 50px;
}
.logo{
    height: 80px;
    
    transform: translateY(1);
    font-size: 100px;
    margin-left: 6%;
    
}
nav ul{
    float: right;
    margin-right: 20px;
}
nav ul li{
    display: inline-block;
    line-height: 80px;
    margin: 0 5px;
}
nav ul li a{
    color: #fff;
    font-size: 18px;
    padding: 7px 13px;
    border-radius: 3px;
    text-transform: uppercase;
}
li a.active, li a:hover{
    background: brown;
    transition: .5s;
}
.checkbtn{
    font-size: 30px;
    color: #fff;
    float: right;
    line-height: 80px;
    margin-right: 40px;
    cursor: pointer;
    display: none;
}
#check{
    display: none;
}
section{
    background: url(img/fondo.jpeg) no-repeat;
    background-size: cover;
    background-position: center center;
    height: calc(100vh - 80px);
}

@media 

  (max-width: 952px){
    .enlace{
        padding-left: 20px;
    }
    nav ul li a{
        font-size: 16px;
    }
}

@media (max-width: 858px){
    .checkbtn{
        display: block;
    }
    ul{
        position: fixed;
        width: 100%;
        height: 100vh;
        background: #2c3e50;
        top: 80px;
        left: -100%;
        text-align: center;
        transition: all .5s;
    }
    nav ul li{
        display: block;
        margin: 50px 0;
        line-height: 30px;
    }
    nav ul li a{
        font-size: 20px;
    }
    li a:hover, li a.active{
        background: none;
        color: red;
    }
    #check:checked ~ ul{
        left:0;
    }
}

</style>

</head>
<body>
    <nav>
        <input type="checkbox" id="check">
        <label for="check" class="checkbtn">
            <i class="fas fa-bars"></i>
        </label>
        <a href="#" class="enlace">
            <img src="img/logo.png" alt="" class="logo">
        </a>
        <ul>
            <li><a href="indice.php">Registrar Docente</a><br></li>
              <li>  <a href="estudiante.php">Registrar Estudiante</a> <br></li>
                <li><a href="acudiente.php">Registrar Acudiente</a><br></li>
               <li><a href="curso.php">Registrar Curso</a><br></li> 
                <li><a href="reporte.php">Generar Reporte</a><br></li>
            
        </ul>
    </nav>
    <section></section>
</body>
</html>

<center>    
<table>
    <tr>
        <th>nombre</th>
        <th>director de grupo</th>
        <th>modalidad</th>
        <th>jornada</th>
        <th>opciones</th>
    
    </tr>
   
<?php 
$xd = include("con_db.php");
if ($xd) {
	$consulta = "SELECT * FROM curso";
	$resultado = mysqli_query($conexion,$consulta);
	if ($resultado) {
		while ($pro = $resultado->fetch_array()) {
	    $codigo = $pro['codigo'];
        $id_doncente=$pro['id_doncente'];
        $modalidad=$pro['modalidad'];
        $jornada=$pro['jornada'];
	    ?>
                <tr>
        			<td> <?php echo$codigo; ?></td>
                    <td>  <?php echo $id_doncente; ?></td>
                  <td><?php  echo $modalidad; ?></td> 
                  <td> <?php echo $jornada; ?></td>
                  <td><nbsp><a href="eliminar(curso)_html.php?id=<?php echo $codigo; ?>" style=color:red > eliminar<a> <p>-</p> <a href="actualizar(curso)_html.php?id=<?php echo $codigo; ?>" style=color:#7CFC00> actualizar<a> </nbsp>
                         </td>
                 </tr>    
        		   
        	
	    <?php
	    }
	}
}
?></table> </center>

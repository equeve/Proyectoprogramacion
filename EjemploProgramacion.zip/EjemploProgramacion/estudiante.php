<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta charset="utf-8">
    <link rel="stylesheet" type="text/css" href="base.css">
    <link rel="stylesheet" type="text/css" href="menu.css">
    <link rel="stylesheet" type="text/css" href="estilo.css">
    <title>estudiante</title>
</head>
<body>

    <nbsp>
      <?php
      include("menu.php")
      ?>
<form method="post">
    	<h1>ingrese los datos del estudiante</h1>
		<input type="number" name="1" placeholder="ingrese la docuemnto  del estudiante">
    	<input type="text" name="2" placeholder="Nombre completo">
		<input type="text" name="3" placeholder="apellido">
		<select type="number" name="4" placeholder="codigo de curso">
        <?php  include("con_db.php"); 
            
            $consul="SELECT * FROM curso";
            $ejecutar=mysqli_query($conexion,$consul) or die(mysqli_error($conexion));
            ?>
            <?php foreach($ejecutar as $opciones):?>
            
        <option value="<?php echo $opciones['codigo']?>"><?php echo $opciones['codigo']?> </option>

            <?php   endforeach  ?>
        </select>
        </select>
		<input type="text" name="5" placeholder="ingrese su lugar de nacimiento">
    	<input type="date" name="6" placeholder="fecha de nacimiento">
		<select type="text" name="7" class="form-control" required>
                    <option value= "padres">padres</option>
                    <option value="mama">mama</option>
                    <option value= "papa">papa</option>
                </select>
        <input type="number" name="8" placeholder="edad">
        <input type="text" name="9" placeholder="eps">
        <input type="text" name="10" placeholder="sisben">
    	<input type="submit" name="register_2">
        <?php 
        include("registrador2.php");
        ?>
    </form></nbsp>
</body>
</html>
<!DOCTYPE html>
<html>
<head>
	<title>Registrar usuario</title>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="menu.css">
	<body>
<?php
include("menu.php")
?>
    </body>
</html>
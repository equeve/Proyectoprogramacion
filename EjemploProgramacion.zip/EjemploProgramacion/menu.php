<nav class="navegacion">
			<ul class="menu">
                    <li>
                         <a href="index.php">inicio</a>
                    </li>
				<li><a href="indice.php">Registrar docente</a>
                    <ul class="submenu"><li> <a href="consultar_docente.php">Consultar docente</a></li></ul></li>

				<li><a href="estudiante.php">Registrar estudiante</a>
                    <ul class="submenu"><li> <a href="consultador_es.php">Consultar estudiante</a></li></ul></li>
				
                <li><a href="acudiente.php">Registrar acudiente</a>
                    <ul class="submenu">
                    <li>
                    <a href="consulta(acu).php">Consultar acudiente </a> 
                  </li>
                    </ul>

				<li><a href="curso.php">Registrar curso</a>
                <ul class="submenu"><li><a href="consulta(cu).php"> Consultar curso</a></li></ul></li>
                <li> <a href="reporte.php">reporte</a>
                 <ul class="submenu"><li><a href="consulta_re.php"> Consultar reportes</a></li></ul></li>
			</ul>
		</nav>
	</header>
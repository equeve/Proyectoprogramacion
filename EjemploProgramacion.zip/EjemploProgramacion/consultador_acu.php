
    
<table>
    <tr><center>
        <th>numero de documento</th>
        <th>nombre</th>
        <th>apellido</th>
        <th>telefono</th>
        <th>direccion</th>
        <th>sexo</th>
        <th>estudiante</th>
        <th>opciones</th>
        
    </center>
    </tr>
   
<?php 
$xd = include("con_db.php");
if ($xd) { if(isset($_POST['a'])){
if($_POST['s']!=null){$a=$_POST['s'];
    $consulta = "SELECT * FROM acudiente where id =$a";
}else{$consulta = "SELECT * FROM acudiente";};

if($_POST['d']!=null){$a=$_POST['d'];
    $consulta = "SELECT * FROM acudiente where id =$a";
}

}else{$consulta = "SELECT * FROM acudiente";}
    
	$resultado = mysqli_query($conexion,$consulta);
	if ($resultado) {
		while ($pro = $resultado->fetch_array()) {
	    $id = $pro['id'];
	    $nombre = $pro['nombre'];
        $apellido=$pro['apellido'];
        $telefono=$pro['telefono'];
        $dir=$pro['direccion'];
        $sexo=$pro['sexo'];
	    $estudiante= $pro['matricula_estudiante'];
	    ?>
                <tr><center>
        			<td> <?php echo$id; ?></td>
                    <td><?php echo $nombre; ?></td>
                    <td>  <?php echo $apellido; ?></td>
                  <td> <?php echo $telefono; ?></td>
        		   <td> <?php echo $dir; ?></td>
                     <td> <?php echo $sexo; ?></td>
                      <td> <?php echo $estudiante; ?></td>
                      <td> <nbsp><a href="eliminar(acudiente)_html.php?id=<?php echo $id; ?>" style=color:red > eliminar<a> <p>-</p> <a href="actualizar(acudiente)_html.php?id=<?php echo $id; ?>" style=color:#7CFC00> actualizar<a> </nbsp>
                         
                     </td>
                 </tr>    
        		   
        	
	    <?php
	    }
	}
}
?>



</table>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="estilo.css">
    <link rel="stylesheet" type="text/css" href="menu.css">
    <link rel="stylesheet" type="text/css" href="base.css">
    <title>Document</title>
</head>
<body><nbsp>
  <?php include("menu.php")?>
    <?php 
    include("actualizar(acudiente)_codigo.php")
    ?>
    <section id="container">
    <form method="post">
    	<h1>ingrese los datos del acudiente</h1>
		<h2>documento:<?php echo  $id ;?></h2>
    	<input type="text" name="2" value="<?php echo  $nombre ;?>" placeholder="Nombre completo">
		<input type="text" name="3" value="<?php echo  $apellido ;?>" placeholder="ingrese su apellido">
		<input type="number" name="4" value="<?php echo  $telefono ;?>" placeholder="ingrese su numero de telefono">
		<input type="text" name="5" value="<?php echo  $dir ;?>"placeholder="ingrese su direccion">
    	<select name="6" id="">
		<option value="femenino">femenino</option>
		<option value="masculino">masculino</option>
		</select>
		<input type="number" name="7" value="<?php echo  $estudiante ;?>" placeholder="ingrese el documento del estudiante">
    	<input type="submit" name="register_4">

    </form>


    
    </section>
</nbsp>
</body>
</html>
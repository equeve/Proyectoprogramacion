<?php
$dbhost="localhost";
$dbuser="root";
$dbpass="";
$dbname="pobsonline";
$conexion = mysqli_connect($dbhost,$dbuser,$dbpass,$dbname);
if (!$conexion){die("no hay conexion".mysqli_connect_error());}


?>
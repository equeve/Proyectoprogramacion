<?php 
if(empty($_REQUEST["id"])){ alert("es posible que ese id no exista") ;header("location:consultador_es.php");}else{
    include("con_db.php");
    $id_reporte=$_REQUEST['id'];
    $consulta=mysqli_query($conexion,"SELECT*FROM reporte   INNER JOIN estudiante ON reporte.matricula_estudiante=estudiante.matricula_estudiante where  reporte.id_reporte='$id_reporte'");
    $resultado=mysqli_num_rows($consulta);
        if($resultado>0){
            while($pro=mysqli_fetch_array($consulta)){
        $id = $pro['matricula_estudiante'];
	    $nombre = $pro['nombre'];
        $apellido=$pro['apellido'];
        $curso=$pro['curso'];
        $nac=$pro['lugar_nacimiento'];
        $fec=$pro['fecha_nacimiento'];
	    $vive_con= $pro['vive_con'];
	    $edad = $pro['edad'];
        $EPS=$pro['EPS'];
        $sis=$pro['sisben'];
        $fecha=$pro['fecha'];
        $anotaciones=$pro['anotaciones'];
        $id_d=$pro['id_doncente'];
            }
            
            if(isset($_POST['eliminador'])){
                $codigo="DELETE FROM reporte where id_reporte='$id_reporte'";
        $resultado=mysqli_query($conexion,$codigo);
        if($resultado){  echo'<script>
            
            alert("se a eliminado correctamente");
            location="consulta_re.php";
            
            </script>';  }
            }
            
            ?>



<?php

}

}
?>

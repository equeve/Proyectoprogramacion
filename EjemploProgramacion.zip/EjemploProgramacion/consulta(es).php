


<table>
    <tr><center>
        <th>documento</th>
        <th>nombre</th>
        <th>apellido</th>
        <th>curso</th>
        <th>lugar de nacimiento</th>
        <th>fecha de nacimiento</th>
        <th>vive con</th>
        <th>edad</th>
        <th>eps</th>
        <th>sisben</th>
        <th>opciones</th>
    </center>
    </tr>
   
<?php 
$xd = include("con_db.php");

if ($xd) {
    if(isset($_POST['consultador1'])){
        if ($_POST['e_curso']!=0) { $c=$_POST['e_curso'];
            $consulta = "SELECT * FROM estudiante where curso='$c' order by apellido";
        }else{$consulta = "SELECT * FROM estudiante order by apellido";}
    }else{$consulta = "SELECT * FROM estudiante order by apellido";};
	
	$resultado = mysqli_query($conexion,$consulta);
	if ($resultado) {
		while ($pro = $resultado->fetch_array()) {
	    $id = $pro['matricula_estudiante'];
	    $nombre = $pro['nombre'];
        $apellido=$pro['apellido'];
        $curso=$pro['curso'];
        $nac=$pro['lugar_nacimiento'];
        $fec=$pro['fecha_nacimiento'];
	    $vive_con= $pro['vive_con'];
	    $edad = $pro['edad'];
        $EPS=$pro['EPS'];
        $sis=$pro['sisben'];
	    ?><center>
                <tr>
        			<td> <?php echo$id; ?></td>
                    <td><?php echo $nombre; ?></td>
                    <td>  <?php echo $apellido; ?></td>
                  <td><?php  echo $curso; ?></td> 
                  <td> <?php echo $nac; ?></td>
        		   <td> <?php echo $fec; ?></td>
                     <td> <?php echo $vive_con; ?></td>
                      <td> <?php echo $edad; ?></td>
                      <td> <?php echo $EPS; ?></td>
                      <td> <?php echo $sis; ?></td>
                      <td><nbsp><a href="eliminar(estudiante)_html.php?id=<?php echo $id; ?>" style=color:red > eliminar<a> <p>-</p> <a href="actualizar(estudiante)_html.php?id=<?php echo $id; ?>" style=color:#7CFC00> actualizar<a> </nbsp>
                         </td>
                 </tr>    
        		    </center>
        	
	    <?php
	    }
	}
}
?>



</table>
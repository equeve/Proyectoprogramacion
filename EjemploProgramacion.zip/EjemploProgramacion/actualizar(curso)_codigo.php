<?php
if(empty($_REQUEST['id'])){ alert("es posible que ese id no exista") ;header("location:consultar_docente.php");}else{
    include("con_db.php");
    $codigo=$_REQUEST["id"];
    $consulta=mysqli_query($conexion,"SELECT *FROM curso WHERE codigo = '$codigo'");
    $resultado=mysqli_num_rows($consulta);
        if($resultado>0){
            while($pro=mysqli_fetch_array($consulta)){
                $codigo = $pro['codigo'];
                $id_doncente=$pro['id_doncente'];
                $modalidad=$pro['modalidad'];
                $jornada=$pro['jornada'];
            }
             }  
              }

              if(isset($_POST['actualizar'])){

                for ($i=2;$i<5;$i++){
                    if(strlen($_POST["$i"]) == 0){
                        ?>
                        <h3 class="bad">por favor complete todos los campos</h3>
                        <?php
                        exit();
                        };
                        $formulario[$i]=$_POST["$i"];
                };
                $actualizar="UPDATE curso SET jornada='$formulario[2]',modalidad='$formulario[3]', id_doncente='$formulario[4]' where codigo='$codigo';";
                $resultado=mysqli_query($conexion,$actualizar);
                if($resultado){
            
                    echo'<script>
                        
                        alert("se a actualizado correctamente");
                        location="consulta(cu).php";
                        
                        </script>'; 
                }
                 }


?>

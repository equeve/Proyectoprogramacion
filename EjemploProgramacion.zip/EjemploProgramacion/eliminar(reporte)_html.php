<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="estilo.css">
    <link rel="stylesheet" type="text/css" href="menu.css">
    <link rel="stylesheet" type="text/css" href="base.css">
    <title>Eliminar registro</title>
</head>
    <body>

    <?php  include("menu.php"); ?>     
<?php  include("eliminar(reporte)_codigo.php"); ?>
<section id="container">
<div> 
    <h2>¿estas seguro de eliminar al siguente estudiante de la base de datos?</h2>
    <p>matricula del estudiante:<span><?php echo $id;  ?></span></p>
    <p>nombre:<span><?php echo $nombre;  ?></span></p>
    <p>apellido:<span><?php echo $apellido;  ?></span></p>
    <p>curso:<span><?php echo $curso;  ?></span></p>
    <p>lugar de nacimiento:<span><?php echo $nac;  ?></span></p>
    <p>fecha de nacimiento:<span><?php echo $fec;  ?></span></p>
    <p>vive con:<span><?php echo $vive_con;  ?></span></p>
    <p>edad:<span><?php echo $edad;  ?></span></p>
    <p>eps:<span><?php echo $EPS;  ?></span></p>
    <p>sis:<span><?php echo $sis;  ?></span></p>
    <p>fecha del reporte:<span><?php echo $fecha;  ?></span></p>
    <p>anotaciones del reporte:<span><?php echo $anotaciones;  ?></span></p>
    <p>doncente que realizo el reporte:<span><?php echo $id_d;  ?></span></p>
    <form method="post">

        <a href="consultador.php">cancelar</a>
        <input type="submit" value="eliminar" name="eliminador">
    </form>
</section>

    </body>
</html>
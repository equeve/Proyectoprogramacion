<!DOCTYPE html>
<html>
<head>
	<title>Registrar usuario</title>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="estilo.css">
	<link rel="stylesheet" type="text/css" href="base.css">
  <link rel="stylesheet" type="text/css" href="menu.css">
</head>
<body>
  
 <nbsp>
   <?php
   include("menu.php")
   ?>
    <form method="post">
    	<h1>ingrese los datos del docente</h1>
		<input type="number" name="1" placeholder="ingrese su cedula">
    	<input type="text" name="2" placeholder="Nombre completo">
		<input type="text" name="3" placeholder="ingrese su apellido">
		<input type="number" name="4" placeholder="ingrese su numero de telefono">
		<input type="text" name="5" placeholder="ingrese su direcion">
    	<input type="text" name="6" placeholder="Email">
		<input type="text" name="7" placeholder="contraseña">
    	<input type="submit" name="register">
		<a href="consultar_docente.php">Cosultar docente</a>
		
    </form>
        <?php 
        include("prueba(codigo).php");
        ?></nbsp>
</body>
</html>
create database pobsonline;
use pobsonline;


 create table estudiante(
 matricula_estudiante int (10) primary key ,
 nombre varchar (20) not null,
 apellido varchar (20) not null,
 curso int(10) not null,
 lugar_nacimiento varchar(20) not null,
 fecha_nacimiento date not null ,
 vive_con varchar (20) not null,
 edad int(10)not null,
 EPS varchar (10) not null,
 sisben varchar (10 ) not null
 );

create table reporte (
matricula_estudiante int (10) not null references estudiante,  
fecha date not null,
anotaciones text not null,
id_doncente int (10) not null references docente,
id_reporte int(20) AUTO_INCREMENT primary key
);

create table docente( 
id_doncente int (20) primary key,
nombre_docente varchar (20) not null,
apellido_docente  varchar (20) not null,
telefono int (20) not null,
direccion varchar (20) not null,
contraseña varchar  (40) not null, 
usuario varchar (30) not null
);
create table acudiente(
id int(20) primary key,
nombre varchar (20) not null,
apellido varchar (20) not null,
telefono int(30) not null,
direccion varchar (20) not null,
sexo varchar (10) not null,
matricula_estudiante int (10) references estudiante

);
create table curso(
codigo int(10) primary key,
 id_doncente int (20) not null references docente,
 modalidad varchar (10) not null,
jornada varchar(10) not null
);
create table modalidad (
id int(10) AUTO_INCREMENT primary key,

nombre varchar (20) not null


);
insert into modalidad (nombre) value ('metalizado');
insert into modalidad (nombre) value ('carpinteria metalica');
insert into modalidad (nombre) value ('muebles');
insert into modalidad (nombre) value ('diseño');
insert into modalidad (nombre) value ('tecnico en sistema');
insert into modalidad (nombre) value ('ambiental');
insert into curso (codigo,id_doncente,modalidad,jornada)value(1101,4536,'metalizado','unica');
insert into curso (codigo,id_doncente,modalidad,jornada)value(1102,7566,'carpinteria metalica','unica');
insert into curso (codigo,id_doncente,modalidad,jornada)value(1103,9738,'muebles','unica');
insert into curso (codigo,id_doncente,modalidad,jornada)value(1104,4931,'diseño','unica');
insert into curso (codigo,id_doncente,modalidad,jornada)value(1105,4536,'tecnico en sistema','unica');
insert into estudiante(matricula_estudiante,nombre,apellido,curso,lugar_nacimiento,fecha_nacimiento,vive_con,edad,EPS,sisben)value(5436,'santiago','vizcaino',1105,'barranquilla','10-90-2022','padres',13,'valdes',1);
insert into docente(id_doncente,nombre_docente,apellido_docente,telefono,direccion,contraseña,usuario) value(4234,'jesus','noguera',321412,'villa humilde','santi','1234');
INSERT INTO `docente` (`id_doncente`, `nombre_docente`, `apellido_docente`, `telefono`, `direccion`, `contraseña`, `usuario`) VALUES ('1', '1', '1', '1', '1', '1', '1');
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="consulta.css">
    <link rel="stylesheet" type="text/css" href="menu.css">
    <link rel="stylesheet" type="text/css" href="base.css">
    <title>Document</title>
</head>
<style></style>
<body> 
    
<nbsp>
  <?php
  include("menu.php")
  ?>
<center>
    <?php
    include("consulta_cu.php");
    
    ?></nbsp>
    </center>
</body>
</html>
<?php
include("con_db.php");
$formulario=[0];

if(isset($_POST['register_2'])){
for ($i=1;$i<11;$i++){
if(strlen($_POST["$i"]) == 0){
?>
<h3 class="bad">por favor complete todos los campos</h3>
<?php
exit();
}
if(strlen($_POST["$i"]) == 1 ){
    $x=$_POST[1];
    $verificacion= mysqli_query($conexion,"SELECT*FROM estudiante where matricula_estudiante ='$x' ");
    if(mysqli_num_rows($verificacion) >0){
        echo'<script>
        alert("error matricula ya registrado");
        location="estudiante.php";
        </script>';
        exit();}}$formulario[$i]=$_POST["$i"];}
        $consulta =" INSERT INTO estudiante (matricula_estudiante, nombre, apellido, curso, lugar_nacimiento,fecha_nacimiento,vive_con,edad,EPS,sisben) VALUES ('$formulario[1]', '$formulario[2]', '$formulario[3]', '$formulario[4]', '$formulario[5]', '$formulario[6]', '$formulario[7]', '$formulario[8]', '$formulario[9]', '$formulario[10]');";
	    $resultado = mysqli_query($conexion,$consulta);
        if($resultado){
            ?><h1 class="ok">registradon con exito</h1><?php
        }else{?><h1 class="bad">error en la registracion</h1><?php
        }
}
?>
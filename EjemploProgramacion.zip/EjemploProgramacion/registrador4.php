<?php
include("con_db.php");
$formulario=[0];

if(isset($_POST['register_4'])){
for ($i=1;$i<8;$i++){
if(strlen($_POST["$i"]) == 0){
?>
<h3 class="bad">por favor complete todos los campos</h3>
<?php
exit();
}
if(strlen($_POST["$i"]) == 1 or strlen($_POST["$i"])==7 ){
    $x=$_POST["$i"];
    $verificacion= mysqli_query($conexion,"SELECT*FROM acudiente where id ='$x'");
    if(mysqli_num_rows($verificacion) >0){
        echo'<script>
        alert("error acudiente ya registrado");
        location="acudiente.php";
        </script>';
        exit();}
        $verificacion= mysqli_query($conexion,"SELECT*FROM acudiente where matricula_estudiante ='$x'");
        if(mysqli_num_rows($verificacion) >0){
            echo'<script>
            alert("error acudiente ya registrado");
            location="acudiente.php";
            </script>';
            exit();}
    }$formulario[$i]=$_POST["$i"];}
        $consulta = "INSERT  INTO acudiente(id,nombre,apellido,telefono,direccion,sexo, matricula_estudiante) VALUES ('$formulario[1]','$formulario[2]','$formulario[3]','$formulario[4]','$formulario[5]','$formulario[6]','$formulario[7]')";
	    $resultado = mysqli_query($conexion,$consulta);
        if($resultado){
            ?><h1 class="ok">registradon con exito</h1><?php
        }else{?><h1 class="bad">error en la registracion</h1><?php
         }
}
?>